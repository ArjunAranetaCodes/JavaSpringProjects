package com.example.graphqlserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqlServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
